#ifndef BOOLEAN_H
#define BOOLEAN_H

typedef enum {
	false = 0,
	true = 1
}	t_bool;

#endif
