#include "boolean.h"

t_bool	is_number(char c)
{
	return (c >= '0' && c <= '9');
}
