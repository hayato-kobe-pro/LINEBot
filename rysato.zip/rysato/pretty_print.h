#ifndef PRETTY_PRINT_H
#define PRETTY_PRINT_H

#include "string_utils.h"

void	print_grid(int **grid, int size);

#endif
