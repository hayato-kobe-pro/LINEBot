#ifndef STRING_UTILS_H
#define STRING_UTILS_H

int		str_length(char *str);

void	str_write(char *str);

void	str_write_char(char c);

#endif
