#ifndef IS_H
#define IS_H

#include "boolean.h"

t_bool	is_number(char c);

#endif
