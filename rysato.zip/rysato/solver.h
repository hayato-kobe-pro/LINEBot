#ifndef SOLVER_H
#define SOLVER_H

# include "boolean.h"

t_bool	solve(int grid_size, char *raw_args);

#endif
